# Commercial Licensing

This project is made available under the Polyform Noncommercial License 1.0.0 (see `LICENSE`), which permits noncommercial use and prohibits commercial use.

If you want to use this software for a commercial purpose (including internal use at a for-profit company, embedding into a paid product, or providing it as part of a paid service), you must obtain a separate commercial license from the licensor.

To request commercial licensing terms, contact the project owner/maintainer.
